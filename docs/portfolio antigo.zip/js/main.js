$(document).ready(function(){
    //Código
});